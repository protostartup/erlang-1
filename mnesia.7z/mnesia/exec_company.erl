%"C:\Program Files\erl10.1\bin\werl.exe" -s odbc start  -mnesia dir '"c:/Angelo/erl/DB"'

mnesia:create_schema([node()]).

mnesia:start().

mnesia:info().

cd("c:/Angelo/Downloads/Erlang/mnesia/").

c(company).

mnesia:info().

company:start().

Emp = #employee{emp_no= 104732,
                name = klacke,
                salary = 7,
                sex = male,
                phone = 98108,
                room_no = {221, 015}},

insert_emp(Me, 'B/SFR', [Erlang, mnesia, otp]).

